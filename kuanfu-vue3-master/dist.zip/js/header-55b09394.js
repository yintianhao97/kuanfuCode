const e="/assets/header-1b5fa5f8.jpg";export{e as h};
