import{y as o}from"./jeecg-online-vendor-37ee1c88.js";import{B as a}from"./BasicModal-e8b6dac8.js";import"./index-a69735e8.js";const r=o(a);export{r as B};
