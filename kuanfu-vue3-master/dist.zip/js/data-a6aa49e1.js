const t=(()=>{const o=[];for(let e=0;e<12;e++)o.push({title:"Jeecg Admin",icon:"logos:vue",color:"#1890ff",active:"100",new:"1,799",download:"bx:bx-download"});return o})();export{t as cardList};
