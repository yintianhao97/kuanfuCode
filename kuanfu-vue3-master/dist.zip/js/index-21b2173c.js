import{d as u,f as n,r as a,o as s,a6 as i,a7 as c,ac as p}from"./tinymce-vendor-3c2b3d6e.js";import{C as m}from"./htmlmixed-3cc08d8a.js";import"./vue-1f4e4a2c.js";import{_ as d}from"./jeecg-online-vendor-37ee1c88.js";import"./codemirror-vendor-0a03fef5.js";import"./antd-vue-vendor-7a719e2c.js";import"./vxe-table-vendor-26792376.js";const C=u({components:{},setup(){const t=window.CodeMirror||m,e=n(null),o=a({tabSize:2,theme:"cobalt",lineNumbers:!0,line:!0});s(()=>{r()});function r(){t.fromTextArea(e.value,o)}return{textarea:e}}}),f={ref:"textarea"};function l(t,e,o,r,_,x){return i(),c("div",null,[p("textarea",f,`
白日依山尽，黄河入海流。
欲穷千里目，更上一层楼。
        `,512)])}const h=d(C,[["render",l]]);export{h as default};
